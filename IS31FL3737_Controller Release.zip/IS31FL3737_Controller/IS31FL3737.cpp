
#include "IS31FL3737.hpp"

extern uint8_t data[64];
uint8_t IS3737_Pwm[192];
uint8_t IS31_Address;

void IS31FL3737_Select_Sw_Pull(uint8_t dat)
{ 
	   I2C_WriteByte(IS31_Address,0xFE,0xc5);//unlock FDh
	   I2C_WriteByte(IS31_Address,0xFD,0x03);//write page 2
     I2C_WriteByte(IS31_Address,0x0f,dat);//none
}
void IS31FL3737_Select_Cs_Pull(uint8_t dat)
{
	   I2C_WriteByte(IS31_Address,0xFE,0xc5);//unlock FDh
	   I2C_WriteByte(IS31_Address,0xFD,0x03);//write page 2
	   I2C_WriteByte(IS31_Address,0x10,dat);
}

/* write full frame buffer to IS31 */
void IS31FL3737_Send_PixBuf(void)
{
  I2C_WriteByte(IS31_Address,0xFE,0xc5);//unlock FDh
  I2C_WriteByte(IS31_Address,0xFD,0x01);//write page 1
  I2C_BufferWrite(IS3737_Pwm, 192, 0x00, IS31_Address);
}

/* write RGB value to one pixel in the frame buffer */
void IS31FL3737_Set_PixBuf(uint8_t pixel, uint8_t red, uint8_t green, uint8_t blue)
{
  uint8_t hex[3]={0};
  IS31FL3737_Get_Pixel(pixel, hex);
  IS3737_Pwm[hex[0]] = red;
  IS3737_Pwm[hex[1]] = green;
  IS3737_Pwm[hex[2]] = blue;
}

/* read RGB value from one pixel in the frame buffer */
void IS31FL3737_Get_PixBuf(uint8_t pixel, uint8_t phex[])
{
  uint8_t hex[3]={0};
  IS31FL3737_Get_Pixel(pixel, hex);
  phex[0] = IS3737_Pwm[hex[0]];
  phex[1] = IS3737_Pwm[hex[1]];
  phex[2] = IS3737_Pwm[hex[2]];
}

uint8_t IS31FL3737_Get_Pixel(uint8_t pixel, uint8_t phex[])
{
  if(pixel > 25) return 1;

  phex[0] = RGB[pixel][0];
  phex[1] = RGB[pixel][1];
  phex[2] = RGB[pixel][2];
  return 0;
}

uint8_t IS31FL3737_Init(uint8_t IS31_Addr)
{
  uint8_t i;
  uint8_t error=0;

  I2C_GPIO_Initial();
  IS31_Address = IS31_Addr;

  error = I2C_WriteByte(IS31_Address,0xFE,0xc5); //unlock FDh, check for connectivity too
  if(error) return error;
  //else, keep going
  I2C_WriteByte(IS31_Address,0xFD,0x00);//write page 0
  for(i=0;i<24;i++)
    I2C_WriteByte(IS31_Address,i,0xff);//open all led

  I2C_WriteByte(IS31_Address,0xFE,0xc5);//unlock FDh
  I2C_WriteByte(IS31_Address,0xFD,0x03);//write page 3 
  I2C_WriteByte(IS31_Address,0x00,0x01);//normal operation	
  //00h set 0X01 PWM=8.4K
  //00h set 0X11 PWM=26.7K
  //00h set 0X09 PWM=4.2K
  //00h set 0X19 PWM=2.1K
  //00h set 0X21 PWM=1.05K
  I2C_WriteByte(IS31_Address,0x01,0x7F);//set  global current 1/2 of max
  return error;
}


void IS31FL3737_Global_Current(uint8_t dat)
{
	 I2C_WriteByte(IS31_Address,0xFE,0xc5);//unlock FDh
	 I2C_WriteByte(IS31_Address,0xFD,0x03);//write page 3 
	 I2C_WriteByte(IS31_Address,0x01,dat);//set  global current
}

void IS31FL3737_PWM_ALL_ON(void)
{
			 I2C_WriteByte(IS31_Address,0xFE,0xc5);//unlock FDh
			 I2C_WriteByte(IS31_Address,0xFD,0x01);//write page 1  	
	     I2C_BufferWrite((unsigned char*)all_pwm_on_IS31FL3737, 192,0x00,IS31_Address);
}

void IS31FL3737_PWM_ALL_SCALE(uint8_t scale)
{
			 I2C_WriteByte(IS31_Address,0xFE,0xc5);//unlock FDh
			 I2C_WriteByte(IS31_Address,0xFD,0x01);//write page 1
       for(int i=0; i < 192; i++)  	
	     I2C_WriteByte(IS31_Address, i, scale);
}

void IS31FL3737_PWM_ALL_OFF(void)
{
			 I2C_WriteByte(IS31_Address,0xFE,0xc5);//unlock FDh
			 I2C_WriteByte(IS31_Address,0xFD,0x01);//write page 1 
	     I2C_BufferWrite((unsigned char*)all_pwm_off_IS31FL3737, 192,0x00,IS31_Address);
}

void IS31FL3737_Reset_Pwm_Value(void)
{ 
  uint8_t reset_pwm[192]={0};
  I2C_WriteByte(IS31_Address,0xFE,0xc5);//unlock FDh
  I2C_WriteByte(IS31_Address,0xFD,0x01);//write page 1 	
  I2C_BufferWrite((unsigned char*)reset_pwm, 192,0x00,IS31_Address);
}

/* Enable LEDs, does not necessarily light them up */
void IS31FL3737_ALL_LED_ON(void)
{
  uint8_t leds[24]={0xFF};
  I2C_WriteByte(IS31_Address,0xFE,0xc5);//unlock FDh
  I2C_WriteByte(IS31_Address,0xFD,0x01);//write page 1 	
  I2C_BufferWrite((unsigned char*)leds, 192,0x00,IS31_Address);
}

void IS31FL3737_ABMS_Reset(void)
{
  I2C_WriteByte(IS31_Address,0xFE,0xc5);//unlock FDh
	I2C_WriteByte(IS31_Address,0xFD,0x01);//write page 1
	I2C_BufferWrite((unsigned char*)all_pwm_off_IS31FL3737, 192,0x00,IS31_Address);//write PWM mode
	
	I2C_WriteByte(IS31_Address,0xFE,0xc5);//unlock FDh
	I2C_WriteByte(IS31_Address,0xFD,0x02);//write page 2	
	I2C_BufferWrite((unsigned char*)all_pwm_off_IS31FL3737, 192,0x00,IS31_Address);//write PWM mode
}

//left over from Lumissil example code
void IS31FL3737_ABMS_Control(uint8_t dat)//Receive data from USB
{
		 uint8_t i=0,j=0,k=0;
	  switch(dat)
	{
    case 1:    for(i=0;i<62;i++,j++)
                 {
									 if(k>5)
									 {
										   k=0;
										 j=j+2;
									 }									 
                   IS3737_Pwm[j]=data[2+i];
									 k++;
                 }
							  break;
    case 2:    for(i=62;i<124;i++)
                 {
									 if(k>5)
									  {
										  k=0;
										  j=j+2;
									  }
                   if((i+j+20)==0x56) 
									 {
                      k=0;
										  j=j+2;
                   }										 
                   IS3737_Pwm[i+j+20]=data[i-60];
									 k++;
                 }
							  break;
    case 0xff:    for(i=124;i<186;i++)
                 {
									 if(k>5)
									  {
										   k=0;
										  j=j+2;
									  }
                   if((i+j+40)==0xA6) 
									 {
                      k=0;
										  j=j+2;
                   }											
                    IS3737_Pwm[i+j+40]=data[i-122];
										k++;
                 }	 
		 I2C_WriteByte(IS31_Address,0xFE,0xc5);//unlock FDh
		 I2C_WriteByte(IS31_Address,0xFD,0x01);//weite page 1
	   for(i=0;i<192;i++)
			{
				if(IS3737_Pwm[i]>0)
        I2C_WriteByte(IS31_Address,i,0xff);//write pwm
				else
				I2C_WriteByte(IS31_Address,i,0);//
      }							 
//Return PWM mode								 
		 I2C_WriteByte(IS31_Address,0xFE,0xc5);//unlock FDh
		 I2C_WriteByte(IS31_Address,0xFD,0x02);//write page 2	
		 I2C_BufferWrite((unsigned char*)all_pwm_off_IS31FL3737, 192,0x00,IS31_Address);//write PWM mode
		 break;
		}
}


void IS31FL3737_ABMS_Breath_Time(void)
{
	 I2C_WriteByte(IS31_Address,0xFE,0xc5);//unlock FDh
	 I2C_WriteByte(IS31_Address,0xFD,0x02);//weite page 2
	 I2C_BufferWrite((unsigned char*)IS3737_Pwm, 192,0x00,IS31_Address);
	
	 I2C_WriteByte(IS31_Address,0xFE,0xc5);//unlock FDh
   I2C_WriteByte(IS31_Address,0xFD,0x01);//weite page 1
	 I2C_BufferWrite((unsigned char*)all_pwm_off_IS31FL3737, 192,0x00,IS31_Address);//close all pwm
	
	 I2C_WriteByte(IS31_Address,0xFE,0xc5);//unlock FDh
	 I2C_WriteByte(IS31_Address,0xFD,0x03);//write page 3
   I2C_WriteByte(IS31_Address,0x00,0x03);//Auto breath enable
//ABM-1	
	 data[1]=data[1]<<5;
	 data[2]=data[2]<<1;
	 I2C_WriteByte(IS31_Address,0x02,(data[1]|data[2]));//T1T2
	 data[3]=data[3]<<5;
	 data[4]=data[4]<<1;
	 I2C_WriteByte(IS31_Address,0x03,(data[3]|data[4]));//T3T4
	 data[5]=data[5]<<3;
	 data[6]=data[6]<<6;
	 I2C_WriteByte(IS31_Address,0x04,data[5]|data[6]);//Loop Begin and loop end and loop time Hight bit
	 I2C_WriteByte(IS31_Address,0x05,data[7]);// loop time Low bit  Star and Stop	
//ABM-2	
	 data[8]=data[8]<<5;
	 data[9]=data[9]<<1;
	 I2C_WriteByte(IS31_Address,0x06,(data[8]|data[9]));//T1T2
	 data[10]=data[10]<<5;
	 data[11]=data[11]<<1;
	 I2C_WriteByte(IS31_Address,0x07,(data[10]|data[11]));//T3T4
	 data[12]=data[12]<<3;
	 data[13]=data[13]<<6;
	 I2C_WriteByte(IS31_Address,0x08,data[12]|data[13]);//Loop Begin and loop end and loop time Hight bit
	 I2C_WriteByte(IS31_Address,0x09,data[14]);// loop time Low bit  Star and Stop	
//ABM-3	
	 data[15]=data[15]<<5;
	 data[16]=data[16]<<1;
	 I2C_WriteByte(IS31_Address,0x0A,(data[15]|data[16]));//T1T2
	 data[17]=data[17]<<5;
	 data[18]=data[18]<<1;
	 I2C_WriteByte(IS31_Address,0x0B,(data[17]|data[18]));//T3T4
	 data[19]=data[19]<<3;
	 data[20]=data[20]<<6;
	 I2C_WriteByte(IS31_Address,0x0C,data[19]|data[20]);//Loop Begin and loop end and loop time Hight bit
	 I2C_WriteByte(IS31_Address,0x0D,data[21]);// loop time Low bit  Star and Stop	

	 I2C_WriteByte(IS31_Address,0x0E,0x00);//update resigestI2C_WriteByte(IS31_Address,0x03,data[6]);//T3T4
	 I2C_WriteByte(IS31_Address,0x00,0x03);//Auto breath enable
}


//void OpenShort(uint8_t choose,uint8_t choose1,uint8_t choose2,uint8_t choose3)
//{
////	uint8_t OpenByte, ShortByte;
//	uint8_t i;
//	
//	I2C_WriteByte(IS31_Address,0xFE,0xc5);//unlock FDh
//	I2C_WriteByte(IS31_Address,0xFD,0x03);//write page 3
//	I2C_WriteByte(IS31_Address,0x00,0x01);//normal operation
//  I2C_WriteByte(IS31_Address,0x01,choose);//set global value	
//	I2C_WriteByte(IS31_Address,0xf0,0x0b);//open short enable
//	I2C_WriteByte(IS31_Address,0xf1,0x03);//open short interrupt
//	
//        I2C_WriteByte(IS31_Address,0xFE,0xc5);//unlock FDh
//	I2C_WriteByte(IS31_Address,0xFD,0x00);//write page 0
//        for(i=0;i<24;i++)
//	I2C_WriteByte(IS31_Address,i,choose1);//turn on led
//	
//	I2C_WriteByte(IS31_Address,0xFE,0xc5);//unlock FDh
//	I2C_WriteByte(IS31_Address,0xFD,0x03);//write page 3
//	I2C_WriteByte(IS31_Address,0x00,0x05);//Enable open/short detection
//	delay_ms(3);
//	I2C_WriteByte(IS31_Address,0xFE,0xc5);//unlock FDh
//	I2C_WriteByte(IS31_Address,0xFD,0x00);//write page 0
// 	data[5]=I2C_ReadByte(IS31_Address,choose2);//Read the short/open resigest 
// 	data[6]=I2C_ReadByte(IS31_Address,choose3);
//}
