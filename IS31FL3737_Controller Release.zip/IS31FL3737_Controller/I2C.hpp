

/* Define to prevent recursive inclusion ------------------------------------ */ 
 #ifndef __I2C_H 
 #define __I2C_H 

/* Includes ------------------------------------------------------------------*/ 
#include <Arduino.h>
#include <Wire.h>

/* Exported types ------------------------------------------------------------*/ 
/* Exported constants --------------------------------------------------------*/ 


/* Exported macro ------------------------------------------------------------*/ 
/* Exported functions ------------------------------------------------------- */


void I2C_GPIO_Initial(void);
uint8_t I2C_WriteByte(int DeviceAddress, int WriteAddress, int SendByte);
uint8_t I2C_ReceiveByte(void);
uint8_t I2C_ReadByte(int DeviceAddress,int ReadAddress);
uint8_t I2C_ReadBuffer(uint8_t* pBuffer, int length,int ReadAddress,int DeviceAddress);
uint8_t I2C_BufferWrite(uint8_t* pBuffer,int length,int WriteAddress,int DeviceAddress);
uint8_t I2C_Test(uint8_t DeviceAddress);
void All_LED_OFF(void);

#endif /* __2124_I2C_H */ 

