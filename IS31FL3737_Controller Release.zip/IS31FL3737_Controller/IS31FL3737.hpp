#ifndef __IS31FL3737_H 
#define __IS31FL3737_H 

#include "I2C.hpp" 
#include "IS31FL3737RES.hpp"


//   I2C  Address Options
#define Addr_GND_GND  0x50
#define Addr_SCL_SCL  0x55
#define Addr_SDA_SDA  0x5A
#define Addr_VCC_VCC  0x5F
extern uint8_t IS31_Address;

uint8_t IS31FL3737_Init(uint8_t IS31_Addr);

void IS31FL3737_Send_PixBuf(void);
void IS31FL3737_Set_PixBuf(uint8_t pixel, uint8_t red, uint8_t green, uint8_t blue);
void IS31FL3737_Get_PixBuf(uint8_t pixel, uint8_t phex[]);
uint8_t IS31FL3737_Get_Pixel(uint8_t pixel, uint8_t *hex);
void IS31FL3737_Global_Current(uint8_t dat);
void IS31FL3737_PWM_ALL_ON(void);
void IS31FL3737_PWM_ALL_SCALE(uint8_t scale);
void IS31FL3737_PWM_ALL_OFF(void);
void IS31FL3737_Reset_Pwm_Value(void);
void IS31FL3737_ALL_LED_ON(void);
void IS31FL3737_Select_Sw_Pull(uint8_t dat);
void IS31FL3737_Select_Cs_Pull(uint8_t dat);
void IS31FL3737_Test_All_On_Off(void);
void IS31FL3737_ABMS_Control(uint8_t dat);
void IS31FL3737_ABMS_Reset(void);
void IS31FL3737_ABMS_Breath_Time(void);

#endif 
