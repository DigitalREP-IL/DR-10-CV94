/* Includes ------------------------------------------------------------------*/ 
#include "I2C.hpp" 

/*================================= */
    
/* Private typedef -----------------------------------------------------------*/ 
/* Private define ------------------------------------------------------------*/ 
#define I2C_SPEED 100000 

/* Private macro -------------------------------------------------------------*/ 
/* Private variables ---------------------------------------------------------*/ 


/* Private function prototypes -----------------------------------------------*/ 

void I2C_GPIO_Initial(void)
{
  Wire.setClock(I2C_SPEED);
  Wire.begin();
  

}

// Test for connection, no great registers to read on IS31FL3737B though
// Try a read from Interrupt Status Register
// @param uint8_t Device Address
// @return 0=no error, 1=no data
uint8_t I2C_Test(uint8_t DeviceAddress)
{		
    uint8_t check = 0;
    
    Wire.setTimeout(5); //just shorten up the failure timeout for now
    
    byte len = Wire.requestFrom(DeviceAddress, 1, true);
    if(len ==0){
      check = 1;
    }

    Wire.setTimeout(25);
    return check;
}

//I2C single byte write
// @returns
// 0: success.
// 1: data too long to fit in transmit buffer.
// 2: received NACK on transmit of address.
// 3: received NACK on transmit of data.
// 4: other error.
// 5: timeout
uint8_t I2C_WriteByte(int DeviceAddress, int WriteAddress, int SendByte)
{		
  uint8_t error = 0;
  Wire.beginTransmission(DeviceAddress);
  Wire.write(WriteAddress);
  Wire.write(SendByte);
  error = Wire.endTransmission();
  return error;
}
/*********************************************************************************************************/

// I2C write from buffer
uint8_t I2C_BufferWrite(uint8_t* pBuffer, int length, int WriteAddress, int DeviceAddress)
{   
	  uint8_t error = 0;
    int i = 0;
    Wire.beginTransmission(DeviceAddress);
    Wire.write(WriteAddress);
    while(i < length)
    {
      Wire.write(pBuffer[i]);
      i++;
    }
    error = Wire.endTransmission(true);
    return error;
}

/*********************************************************************************************************/

// I2C single byte read
uint8_t I2C_ReadByte(int DeviceAddress,int ReadAddress)
{		
  uint8_t rec = 0;
  Wire.beginTransmission(DeviceAddress);
  Wire.write(ReadAddress);
  Wire.endTransmission();
  Wire.requestFrom(DeviceAddress, 1, true);    

  while (Wire.available()) // peripheral may send less than requested
  { 
    rec = Wire.read(); // receive a byte as character
  }
  
  return rec;
}


// I2C read to buffer, unused here
uint8_t I2C_ReadBuffer(uint8_t* pBuffer,   int length,     int ReadAddress,  int DeviceAddress)
{		
  if(length == 0)
    return false;

  return true;
}
